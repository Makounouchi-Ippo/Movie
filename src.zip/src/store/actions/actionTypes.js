
/////////////////AUTHENTIFICATIONNNNNN/////////////////////

export const AUTH_START = 'AUTH_START'
export const AUTH_SUCCESS = 'AUTH_SUCCESS'
export const AUTH_FAIL = 'AUTH_FAIL'
export const AUTH_LOGOUT = 'AUTH_LOGOUT'
export const MODAL_FALSE = 'MODAL_FALSE'
export const SOCIAL_AUTH = 'SOCIAL_AUTH'

/////////////////MOVIEEE-SEARCHH/////////////////////


export const MOVIE_BEGIN = 'MOVIE_BEGIN'
export const MOVIE_POPULAR = 'MOVIE_POPULAR'
export const MOVIE_SEARCH_INPUT = 'MOVIE_SEARCH_INPUT'
export const MOVIE_FILTRE = 'MOVIE_FILTRE'
export const MOVIE_FAIL = 'MOVIE_FAIL'
export const INFINITE_SCROLL = 'INFINITE_SCROLL'
export const CLEAR_MOVIE = 'CLEAR_MOVIE'
export const PAGE_INITIAL = 'PAGE_INITIAL'
export const MOVIE_DETAIL = 'MOVIE_DETAIL'


