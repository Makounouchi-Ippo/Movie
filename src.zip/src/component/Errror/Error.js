import React from 'react'
import classes from './Error.css';

const Notfound = () => 
<h1 className= {classes.Error}>Not found</h1>
export default Notfound;